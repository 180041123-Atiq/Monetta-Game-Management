Title: \   A Shooting Game
Description: My first game using the console functions. The left "player" uses q to move up, a to move down, and s to shoot. the right "player" uses o to move up, l to move down, and k to shoot. You can shoot up to 2 bullets at a time. please rate.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=8210&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
